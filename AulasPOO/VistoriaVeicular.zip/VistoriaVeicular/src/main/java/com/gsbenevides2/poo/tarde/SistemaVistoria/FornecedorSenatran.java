package com.gsbenevides2.poo.tarde.SistemaVistoria;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URL;

public class FornecedorSenatran implements FornecedorPrivado{
    private static FornecedorSenatran instance;
    private FornecedorSenatran() {
    }
    public static FornecedorSenatran getInstance() {
        if (instance == null) {
            instance = new FornecedorSenatran();
        }
        return instance;
    }

    private String id = "senatran";
    private String nome = "Secretária Nacional de Trânsito (Senatran)";
    private BigDecimal valor = new BigDecimal("500.00");

    @Override
    public String getId() {
        return id;
    }

    @Override
    public String getNome() {
        return nome;
    }

    @Override
    public BigDecimal getValor() {
        return valor;
    }

    @Override
    public RequisicaoFornecedor fazerRequisicao(Consulta consulta) throws IOException {
        URL url = new URL("http://localhost:3000/senatran/"+ consulta.getPlaca());
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");

        connection.connect();

        BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        String inputLine;
        StringBuilder content = new StringBuilder();
        while ((inputLine = in.readLine()) != null){
            content.append(inputLine);
        }
        in.close();
        connection.disconnect();

        JSONObject json = new JSONObject(content.toString());
        String respostaPura = json.getString("resposta");

        return new RequisicaoFornecedorSenatran(consulta, respostaPura, getValor());
    }
}
