package com.gsbenevides2.poo.tarde.SistemaVistoria;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URL;

public class FornecedorDetran implements FornecedorPrivado {
    private static FornecedorDetran instance;
    private FornecedorDetran() {
    }
    public static FornecedorDetran getInstance() {
        if (instance == null) {
            instance = new FornecedorDetran();
        }
        return instance;
    }

    private String id = "detran-sp";
    private String nome = "Departamento Estadual de Trânsito de São Paulo(DetranSP)";
    private BigDecimal valor = new BigDecimal("100.00");

    @Override
    public String getId() {
        return id;
    }

    @Override
    public String getNome() {
        return nome;
    }

    @Override
    public BigDecimal getValor() {
        return valor;
    }

    @Override
    public RequisicaoFornecedor fazerRequisicao(Consulta consulta) throws IOException {
        URL url = new URL("http://localhost:3000/detran/"+ consulta.getPlaca());
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");

        connection.connect();

        BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        String inputLine;
        StringBuffer content = new StringBuffer();
        while ((inputLine = in.readLine()) != null){
            content.append(inputLine);
        }
        in.close();
        connection.disconnect();

        JSONObject json = new JSONObject(content.toString());
        String respostaPura = json.getString("resposta");

        BigDecimal custoDaRequisicao = getValor();

        return new RequisicaoFornecedorDetran(consulta, respostaPura, custoDaRequisicao);
    }
}
