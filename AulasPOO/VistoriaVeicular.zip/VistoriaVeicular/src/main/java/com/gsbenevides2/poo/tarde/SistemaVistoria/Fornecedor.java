package com.gsbenevides2.poo.tarde.SistemaVistoria;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.ProtocolException;

public interface Fornecedor {
    String getId();
    String getNome();
    BigDecimal getValor();


}

interface FornecedorPrivado extends Fornecedor{
    RequisicaoFornecedor fazerRequisicao(Consulta consulta) throws IOException;
}
