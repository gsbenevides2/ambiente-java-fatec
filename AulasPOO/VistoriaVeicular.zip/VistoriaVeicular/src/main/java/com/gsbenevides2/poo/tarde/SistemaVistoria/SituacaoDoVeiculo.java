package com.gsbenevides2.poo.tarde.SistemaVistoria;

public enum SituacaoDoVeiculo {
    REGULAR, IRREGULAR
}
