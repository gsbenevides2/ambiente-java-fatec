package com.gsbenevides2.poo.tarde;

public abstract class ServicoDeReserva {
    public abstract double getValor();
}
