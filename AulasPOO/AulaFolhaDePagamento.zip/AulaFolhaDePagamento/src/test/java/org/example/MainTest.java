package org.example;

import org.junit.Test;

public class MainTest {
    @Test
    public void testMain() {
        Main.main(null);
    }
}
