package com.gsbenevides2.folhaDePagamento;

public interface IFuncionario {
    public String getCPF();
    public String getNome();
    public double calcularSalario();
}
