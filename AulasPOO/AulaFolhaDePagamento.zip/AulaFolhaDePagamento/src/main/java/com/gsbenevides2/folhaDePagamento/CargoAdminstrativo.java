package com.gsbenevides2.folhaDePagamento;

public enum CargoAdminstrativo {
    SECRETARIA,
    DIRETOR
}
