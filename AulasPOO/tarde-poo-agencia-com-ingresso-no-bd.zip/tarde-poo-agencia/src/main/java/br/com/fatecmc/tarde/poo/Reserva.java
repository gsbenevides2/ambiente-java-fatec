package br.com.fatecmc.tarde.poo;

public interface Reserva {
	
	double calcularValor();
	
}
