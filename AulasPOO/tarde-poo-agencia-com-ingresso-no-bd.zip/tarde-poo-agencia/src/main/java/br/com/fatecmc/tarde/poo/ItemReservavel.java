package br.com.fatecmc.tarde.poo;

public interface ItemReservavel {

}
