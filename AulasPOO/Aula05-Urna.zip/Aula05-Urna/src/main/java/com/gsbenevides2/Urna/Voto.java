package com.gsbenevides2.Urna;

public interface Voto {
}
