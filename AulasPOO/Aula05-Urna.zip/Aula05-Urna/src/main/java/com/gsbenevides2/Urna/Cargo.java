package com.gsbenevides2.Urna;

public enum Cargo {
    PREFEITO, VEREADOR;
}
