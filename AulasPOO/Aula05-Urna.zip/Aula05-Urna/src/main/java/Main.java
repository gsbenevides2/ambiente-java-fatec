import com.gsbenevides2.Inteface.Interface;

public class Main {
    public static void main(String[] args) {
        Interface.getInstance().iniciar();


    }
}