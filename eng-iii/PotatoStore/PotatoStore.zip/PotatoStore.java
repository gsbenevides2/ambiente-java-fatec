package org.example;

public interface PotatoStore {
    Potato orderPotato();
    Potato createPotato();
}
