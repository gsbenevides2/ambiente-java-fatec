package org.example;

public interface Sauce {
    String toString();
}
