package org.example;

public class Muzarela implements Cheese {
    @Override
    public String toString(){
        return "Muzarela";
    }
}
