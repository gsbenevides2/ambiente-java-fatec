package org.example;

public interface Cheese {
    String toString();
}
