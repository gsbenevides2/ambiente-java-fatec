package org.example;

public class Prado implements Cheese {
    @Override
    public String toString() {
        return "Prado";
    }
}
