package org.example;

public class WhiteSauce implements Sauce{
    @Override
    public String toString() {
        return "White Sauce";
    }
}
