package org.example;

public interface Strogonoff {
    String toString();
}
