package org.example;

public class RedSauce implements Sauce{
    @Override
    public String toString() {
        return "Red Sauce";
    }
}
