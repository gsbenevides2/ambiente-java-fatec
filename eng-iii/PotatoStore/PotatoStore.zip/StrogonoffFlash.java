package org.example;

public class StrogonoffFlash implements Strogonoff{
    @Override
    public String toString() {
        return "Strogonoff Flash";
    }
}
