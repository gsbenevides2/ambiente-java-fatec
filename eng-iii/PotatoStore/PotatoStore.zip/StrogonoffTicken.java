package org.example;

public class StrogonoffTicken implements Strogonoff{
    @Override
    public String toString() {
        return "Strogonoff Ticken";
    }
}
