package com.gsbenevides2.bar;

public class Vodka extends Coquetel{
    public Vodka() {
        nome = "Vodka";
        preco = 4.5;
    }
}
