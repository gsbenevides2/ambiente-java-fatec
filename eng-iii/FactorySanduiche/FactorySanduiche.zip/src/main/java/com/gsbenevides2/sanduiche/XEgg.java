package com.gsbenevides2.sanduiche;

public class XEgg extends Sanduiche{
    public XEgg() {
        name = "X-Egg";
        price = 5.5;
    }
}
