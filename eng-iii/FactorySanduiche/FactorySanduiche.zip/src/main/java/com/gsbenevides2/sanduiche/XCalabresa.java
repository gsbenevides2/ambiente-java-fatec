package com.gsbenevides2.sanduiche;

public class XCalabresa extends Sanduiche{
    public XCalabresa() {
        name = "X-Calabresa";
        price = 5.5;
    }

}
