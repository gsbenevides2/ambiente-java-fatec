package com.gsbenevides2.sanduiche;

public class XSalada extends Sanduiche{
    public XSalada() {
        name = "X-Salada";
        price = 5.0;
    }
}
