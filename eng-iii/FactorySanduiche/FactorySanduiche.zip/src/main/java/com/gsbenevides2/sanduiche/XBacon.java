package com.gsbenevides2.sanduiche;

public class XBacon extends Sanduiche{
    public XBacon() {
        name = "X-Bacon";
        price = 6.0;
    }
}
