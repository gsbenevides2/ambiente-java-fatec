package org.example;


import java.util.ArrayList;
import java.util.List;

public interface ISubject {
    List<IObserver> observers = new ArrayList<>();

    public void addObserver(IObserver observer);
    public void removeObserver(IObserver observer);
    public void notifyObservers();
}
