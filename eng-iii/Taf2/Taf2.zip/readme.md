## 2ª Tarefa: Fazer os exercícios com o padrão Strategy

##### Instruções
Entregar o exercício do cachorro seguindo o exemplo do simulador de patos dados em aula. Entregar os códigos e os testes de caixa preta.

Os testes de caixa preta estão na pasta testesCaixaPreta e a IDE utilizada foi o IntelliJ IDEA.