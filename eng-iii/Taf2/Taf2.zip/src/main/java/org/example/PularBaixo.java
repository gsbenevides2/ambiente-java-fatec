package org.example;

public class PularBaixo implements PularComportamento {
	@Override
	public void pular() {
		System.out.println("Pulando bem baixo!");
	}
}
