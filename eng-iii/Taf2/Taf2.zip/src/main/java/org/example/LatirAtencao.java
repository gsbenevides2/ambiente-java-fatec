package org.example;

public class LatirAtencao implements LatirComportamento {
	@Override
	public void latir() {
		System.out.println("AUAUAUAUAUAU, Aten��o!");
	}
}
