package org.example;

public class PularAlto implements PularComportamento {
	@Override
	public void pular() {
		System.out.println("Pulando Muito Alto!");
	}
}
