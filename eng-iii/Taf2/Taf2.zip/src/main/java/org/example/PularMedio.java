package org.example;

public class PularMedio implements PularComportamento{
	@Override
	public void pular() {
		System.out.println("Pulando at� o m�dio.");
	}
}
