package org.example;

public class LatirNervoso implements LatirComportamento {
	@Override
	public void latir() {
		System.out.println("AU AU AU ESTOU NERVOSO!!!!!");
	}
}
