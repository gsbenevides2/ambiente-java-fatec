package org.example;

public interface LatirComportamento {
	public void latir();
}
