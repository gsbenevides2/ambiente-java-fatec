package org.example;

public interface PularComportamento {
	public void pular();
}
