## 3ª Tarefa: Aplicar o padrão Strategy no exemplo do Sedex

##### Instruções
Conforme apresentado em sala de aula, aplicar o padrão Strategy no exemplo do Sedex. Entregar os testes de caixa preta.

Os testes de caixa preta estão na pasta testesCaixaPreta e a IDE utilizada foi o IntelliJ IDEA.