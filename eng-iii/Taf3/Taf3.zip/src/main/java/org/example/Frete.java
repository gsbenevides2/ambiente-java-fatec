package org.example;

public interface Frete {
		public double calcularPreco(int distancia);
}
