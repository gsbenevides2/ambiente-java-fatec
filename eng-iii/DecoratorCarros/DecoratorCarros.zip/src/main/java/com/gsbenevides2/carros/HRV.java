package com.gsbenevides2.carros;

public class HRV extends Veiculo{
    public HRV() {
        nome = "HRV";
        descricao = "Carro popular";
        preco = 50000;
    }
}
