package com.gsbenevides2.carros;

public class ProtetorCard extends Acessorio{
    public ProtetorCard(Veiculo veiculo) {
        super(veiculo);
        nome = "Protetor de Card";
        preco = 1000.0;
        descricao = "Protetor de Card";
    }
}
