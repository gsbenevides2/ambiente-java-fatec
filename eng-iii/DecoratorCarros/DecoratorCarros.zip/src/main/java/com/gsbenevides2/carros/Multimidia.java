package com.gsbenevides2.carros;

public class Multimidia extends Acessorio{
    public Multimidia(Veiculo veiculo) {
        super(veiculo);
        nome = "Multimidia";
        preco = 1000.0;
        descricao = "Central multimidia de ultima geração";
    }
}
