package com.gsbenevides2.carros;

public class Palio extends Veiculo{
    public Palio() {
        nome = "Palio";
        descricao = "Carro popular";
        preco = 25000;
    }
}
