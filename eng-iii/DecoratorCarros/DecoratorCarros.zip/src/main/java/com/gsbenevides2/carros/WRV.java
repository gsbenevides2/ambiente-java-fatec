package com.gsbenevides2.carros;

public class WRV extends Veiculo {
    public WRV() {
        nome = "WRV";
        descricao = "Carro popular";
        preco = 60000;
    }
}
