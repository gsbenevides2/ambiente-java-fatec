package com.gsbenevides2.carros;

public class Twiter extends Acessorio{
    public Twiter(Veiculo veiculo) {
        super(veiculo);
        nome = "Twiter";
        preco = 1000.0;
        descricao = "Twiter de ultima geração";
    }
}
