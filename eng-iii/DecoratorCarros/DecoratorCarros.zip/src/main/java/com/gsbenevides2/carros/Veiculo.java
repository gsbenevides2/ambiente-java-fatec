package com.gsbenevides2.carros;

public abstract class Veiculo {
    String nome;
    String descricao;
    double preco;

    public String getNome() {
        return nome;
    }
    public String getDescricao() {
        return descricao;
    }
    public double getPreco() {
        return preco;
    }
}
