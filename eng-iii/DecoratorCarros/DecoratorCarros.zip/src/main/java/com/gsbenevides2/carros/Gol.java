package com.gsbenevides2.carros;

public class Gol extends Veiculo {
    public Gol() {
        nome = "Gol";
        descricao = "Carro popular";
        preco = 20000;
    }
}
