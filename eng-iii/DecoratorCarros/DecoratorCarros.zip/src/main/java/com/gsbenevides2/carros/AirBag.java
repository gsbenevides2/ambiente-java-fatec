package com.gsbenevides2.carros;

public class AirBag extends Acessorio{

        public AirBag(Veiculo veiculo) {
            super(veiculo);
            nome = "AirBag";
            descricao = "AirBag de alta segurança";
            preco = 1000.0;
        }
}
